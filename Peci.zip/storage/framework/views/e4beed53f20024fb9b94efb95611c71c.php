<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['route', 'active']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['route', 'active']); ?>
<?php foreach (array_filter((['route', 'active']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<a href="<?php echo e(route($route)); ?>" class=" <?php echo e(request()->routeIs($active) ? 'bg-third' : 'bg-second'); ?> w-full py-1.5 rounded-md text-center text-white font-black hover:bg-byolink-3 duration-300 relative">
    <div class=" absolute top-1/2 -translate-y-1/2 left-2 w-4 aspect-square">
        <?php echo e($svg); ?>

    </div>
    <p><?php echo e($slot); ?></p>
    <div class=" absolute top-1/2 -translate-y-1/2 right-2 w-4 aspect-square">
        <?php echo e($svg); ?>

    </div>
</a><?php /**PATH C:\Peci\resources\views/components/admin/mobile-navbutton.blade.php ENDPATH**/ ?>