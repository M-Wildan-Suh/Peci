<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['product']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['product']); ?>
<?php foreach (array_filter((['product']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div class=" w-full grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('product.detail', ['slug' => $item->slug, 'id' => $item->id])); ?>" class=" w-full">
            <div class=" w-full bg-white rounded-md overflow-hidden space-y-2">
                <div class=" w-full aspect-square">
                    <img src="<?php echo e(asset('storage/images/product/'. $item->image)); ?>" alt="">
                </div>
                <div class=" pt-0 p-2">
                    <p class=" line-clamp-1"><?php echo e($item->name); ?></p>
                    <p class=" text-lg font-black">Rp<?php echo e(str_replace(',', '.', number_format($item->price))); ?></p>
                </div>
            </div>
        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH C:\Peci\resources\views/components/guest/component/product.blade.php ENDPATH**/ ?>