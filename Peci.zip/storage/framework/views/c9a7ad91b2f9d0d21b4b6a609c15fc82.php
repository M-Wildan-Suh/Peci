<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['name', 'value', 'status', 'xModel' => null]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['name', 'value', 'status', 'xModel' => null]); ?>
<?php foreach (array_filter((['name', 'value', 'status', 'xModel' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div class="w-full h-full flex flex-col text-sm font-medium gap-2 justify-center items-center">
    <div class="w-full h-full relative flex justify-center overflow-hidden bg-main">
        <img id="<?php echo e($name); ?>-preview" class="object-cover w-full" 
            <?php echo e($xModel ? 'x-bind:src='.$xModel : ''); ?> 
            src="<?php echo e($value == '' ? asset('assets/images/placeholder.webp') : $value); ?>" 
            alt="Logo">
        <div class="w-full h-full absolute z-10 top-0 opacity-0 hover:opacity-100 duration-300">
            <label for="<?php echo e($name); ?>-input" class="relative">
                <div class="w-full h-full bg-black opacity-60 p-[35%] flex justify-center items-center text-neutral-400">
                    <div class=" w-full h-full aspect-square">
                        <svg viewBox="0 0 18 18" xmlns="http://www.w3.org/2000/svg"><path d="M0 14.2V18h3.8l11-11.1L11 3.1 0 14.2ZM17.7 4c.4-.4.4-1 0-1.4L15.4.3c-.4-.4-1-.4-1.4 0l-1.8 1.8L16 5.9 17.7 4Z" fill="currentColor" fill-rule="evenodd" class="fill-000000"></path></svg>
                    </div>
                </div>
                <input accept="image/*" type="file" name="<?php echo e($name); ?>" 
                       class="absolute bottom-0 left-0 z-0 w-40 opacity-0" 
                       id="<?php echo e($name); ?>-input" 
                       <?php echo e(($status ?? '') != '' ? 'required' : ''); ?>

                       oninput="handleImagePreview(this, '<?php echo e($name); ?>-preview')" />
            </label>
        </div>
    </div>
</div>

<script>
    function handleImagePreview(input, previewId) {
        const previewImage = document.getElementById(previewId);
        const [file] = input.files;
        if (file) {
            previewImage.src = URL.createObjectURL(file);
        }
    }

    // Paste event to handle all image inputs
    window.addEventListener('paste', e => {
        const [file] = e.clipboardData.files;
        if (file) {
            document.querySelectorAll('img[id$="-preview"]').forEach(img => {
                img.src = URL.createObjectURL(file);
            });
        }
    });
</script>
<?php /**PATH C:\Peci\resources\views/components/admin/component/imageinput.blade.php ENDPATH**/ ?>