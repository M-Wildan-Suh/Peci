<?php if (isset($component)) { $__componentOriginalf033baadcf10cc1e2c90a9d7fc105a54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf033baadcf10cc1e2c90a9d7fc105a54 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout.guest','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout.guest'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class=" space-y-8 sm:space-y-16 py-8 sm:py-16 px-4 md:px-8">
        <div class=" w-full max-w-[1080px] mx-auto">
            <div class=" w-full grid grid-cols-1 md:grid-cols-3 gap-4">
                <div class=" w-full pr-8">
                    <?php echo $__env->make('components.guest.profile-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="md:col-span-2 w-full space-y-4" x-data="{ activeModal: 'semua' }">
                    <!-- Tabs -->
                    <div class="bg-main rounded-t-md w-full grid grid-cols-5">
                        <button @click="activeModal = 'semua'"
                            :class="activeModal === 'semua' ? 'text-second border-second' :
                                'text-third hover:text-second border-transparent'"
                            class="py-3 font-bold duration-300 border-b-2">
                            Semua
                        </button>
                        <button @click="activeModal = 'dibayar'"
                            :class="activeModal === 'dibayar' ? 'text-second border-second' :
                                'text-third hover:text-second border-transparent'"
                            class="py-3 font-bold duration-300 border-b-2">
                            Dibayar
                        </button>
                        <button @click="activeModal = 'dikirim'"
                            :class="activeModal === 'dikirim' ? 'text-second border-second' :
                                'text-third hover:text-second border-transparent'"
                            class="py-3 font-bold duration-300 border-b-2">
                            Dikirim
                        </button>
                        <button @click="activeModal = 'diterima'"
                            :class="activeModal === 'diterima' ? 'text-second border-second' :
                                'text-third hover:text-second border-transparent'"
                            class="py-3 font-bold duration-300 border-b-2">
                            Diterima
                        </button>
                        <button @click="activeModal = 'selesai'"
                            :class="activeModal === 'selesai' ? 'text-second border-second' :
                                'text-third hover:text-second border-transparent'"
                            class="py-3 font-bold duration-300 border-b-2">
                            Selesai
                        </button>
                    </div>

                    <!-- Modal Content -->
                    <div x-show="activeModal === 'semua'" class=" flex flex-col gap-4">
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->make('components.guest.transaction', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div x-show="activeModal === 'dibayar'" class="space-y-4">
                        <?php $__currentLoopData = $data->filter(fn($item) => $item->status === 'on going'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->make('components.guest.transaction', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div x-show="activeModal === 'dikirim'" class="space-y-4">
                        <?php $__currentLoopData = $data->filter(fn($item) => $item->status === 'on ship'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->make('components.guest.transaction', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div x-show="activeModal === 'diterima'" class="space-y-4">
                        <?php $__currentLoopData = $data->filter(fn($item) => $item->status === 'receive'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->make('components.guest.transaction', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div x-show="activeModal === 'selesai'" class="space-y-4">
                        <?php $__currentLoopData = $data->filter(fn($item) => $item->status === 'success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->make('components.guest.transaction', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf033baadcf10cc1e2c90a9d7fc105a54)): ?>
<?php $attributes = $__attributesOriginalf033baadcf10cc1e2c90a9d7fc105a54; ?>
<?php unset($__attributesOriginalf033baadcf10cc1e2c90a9d7fc105a54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf033baadcf10cc1e2c90a9d7fc105a54)): ?>
<?php $component = $__componentOriginalf033baadcf10cc1e2c90a9d7fc105a54; ?>
<?php unset($__componentOriginalf033baadcf10cc1e2c90a9d7fc105a54); ?>
<?php endif; ?>
<?php /**PATH C:\Peci\resources\views/guest/transaction.blade.php ENDPATH**/ ?>