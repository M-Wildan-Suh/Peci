<div x-show="edit" x-transition:enter="ease-out duration-300" x-transition:enter-start="opacity-0"
    x-transition:enter-end="opacity-100" x-transition:leave="ease-in duration-200" x-transition:leave-start="opacity-100"
    x-transition:leave-end="opacity-0"
    class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-30 px-4">
    <div
        class="w-full max-w-[720px] max-h-[calc(100vh-16px)] bg-white pb-6 text-left rounded-md flex flex-col gap-4 relative border-2 border-main">
        <div class=" pt-6 pb-3 bg-main text-third z-30">
            <h2 class=" px-6 text-2xl font-bold">Edit Address</h2>
            <button @click="edit = false"
                class=" absolute top-6 right-6 w-6 h-6 text-third hover:text-red-500 duration-300">
                <svg viewBox="0 0 512 512" xml:space="preserve" xmlns="http://www.w3.org/2000/svg"
                    enable-background="new 0 0 512 512">
                    <path
                        d="M437.5 386.6 306.9 256l130.6-130.6c14.1-14.1 14.1-36.8 0-50.9-14.1-14.1-36.8-14.1-50.9 0L256 205.1 125.4 74.5c-14.1-14.1-36.8-14.1-50.9 0-14.1 14.1-14.1 36.8 0 50.9L205.1 256 74.5 386.6c-14.1 14.1-14.1 36.8 0 50.9 14.1 14.1 36.8 14.1 50.9 0L256 306.9l130.6 130.6c14.1 14.1 36.8 14.1 50.9 0 14-14.1 14-36.9 0-50.9z"
                        fill="currentColor" class="fill-000000"></path>
                </svg>
            </button>
        </div>
        <form id="<?php echo e($item->id); ?>" action="<?php echo e(route('address.update', ['address' => $item->id])); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="space-y-3 px-6 overflow-auto">
                <?php if (isset($component)) { $__componentOriginalf286e6dababd6dffb177433dbcbd9cb8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf286e6dababd6dffb177433dbcbd9cb8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.component.textinput','data' => ['title' => 'Nama Penerima','placeholder' => 'Input Your Name...','value' => $item->name,'name' => 'name']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.component.textinput'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Nama Penerima','placeholder' => 'Input Your Name...','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item->name),'name' => 'name']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf286e6dababd6dffb177433dbcbd9cb8)): ?>
<?php $attributes = $__attributesOriginalf286e6dababd6dffb177433dbcbd9cb8; ?>
<?php unset($__attributesOriginalf286e6dababd6dffb177433dbcbd9cb8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf286e6dababd6dffb177433dbcbd9cb8)): ?>
<?php $component = $__componentOriginalf286e6dababd6dffb177433dbcbd9cb8; ?>
<?php unset($__componentOriginalf286e6dababd6dffb177433dbcbd9cb8); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal2c520f8144c207bbfb4d831e8a5ba2ea = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2c520f8144c207bbfb4d831e8a5ba2ea = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.component.linkinput','data' => ['title' => 'No Telepone','placeholder' => 'Input Phone Number...','value' => $item->phone_number,'name' => 'phone_number','link' => '+62']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.component.linkinput'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'No Telepone','placeholder' => 'Input Phone Number...','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item->phone_number),'name' => 'phone_number','link' => '+62']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2c520f8144c207bbfb4d831e8a5ba2ea)): ?>
<?php $attributes = $__attributesOriginal2c520f8144c207bbfb4d831e8a5ba2ea; ?>
<?php unset($__attributesOriginal2c520f8144c207bbfb4d831e8a5ba2ea); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2c520f8144c207bbfb4d831e8a5ba2ea)): ?>
<?php $component = $__componentOriginal2c520f8144c207bbfb4d831e8a5ba2ea; ?>
<?php unset($__componentOriginal2c520f8144c207bbfb4d831e8a5ba2ea); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal3978e897aae31f6a8181d56d7a541d3d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3978e897aae31f6a8181d56d7a541d3d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.component.textareainput','data' => ['title' => 'Address','placeholder' => 'Input Address...','value' => $item->address,'name' => 'address']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.component.textareainput'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Address','placeholder' => 'Input Address...','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item->address),'name' => 'address']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3978e897aae31f6a8181d56d7a541d3d)): ?>
<?php $attributes = $__attributesOriginal3978e897aae31f6a8181d56d7a541d3d; ?>
<?php unset($__attributesOriginal3978e897aae31f6a8181d56d7a541d3d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3978e897aae31f6a8181d56d7a541d3d)): ?>
<?php $component = $__componentOriginal3978e897aae31f6a8181d56d7a541d3d; ?>
<?php unset($__componentOriginal3978e897aae31f6a8181d56d7a541d3d); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal3978e897aae31f6a8181d56d7a541d3d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3978e897aae31f6a8181d56d7a541d3d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.component.textareainput','data' => ['title' => 'Aditional','placeholder' => 'Input Aditional...','value' => $item->additional,'name' => 'additional']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.component.textareainput'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Aditional','placeholder' => 'Input Aditional...','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item->additional),'name' => 'additional']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3978e897aae31f6a8181d56d7a541d3d)): ?>
<?php $attributes = $__attributesOriginal3978e897aae31f6a8181d56d7a541d3d; ?>
<?php unset($__attributesOriginal3978e897aae31f6a8181d56d7a541d3d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3978e897aae31f6a8181d56d7a541d3d)): ?>
<?php $component = $__componentOriginal3978e897aae31f6a8181d56d7a541d3d; ?>
<?php unset($__componentOriginal3978e897aae31f6a8181d56d7a541d3d); ?>
<?php endif; ?>
            </div>
        </form>
        
        <div class="pt-4">
            <div class="px-6 w-full flex flex-col-reverse sm:flex-row justify-between items-center gap-4">
                <div class="grid grid-cols-2 gap-3 w-full sm:w-auto">
                    <button type="button" onclick="submitForm(<?php echo e($item->id); ?>)"
                        class="text-sm sm:text-base py-2 px-2 ms:px-4 text-white rounded duration-300 bg-second hover:bg-third">
                        Save
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Peci\resources\views/admin/address/edit.blade.php ENDPATH**/ ?>