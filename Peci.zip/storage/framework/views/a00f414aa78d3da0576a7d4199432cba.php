<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['title', 'placeholder', 'name', 'value', 'xModel' => null]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['title', 'placeholder', 'name', 'value', 'xModel' => null]); ?>
<?php foreach (array_filter((['title', 'placeholder', 'name', 'value', 'xModel' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div class=" w-full">
    <div class=" flex flex-col gap-2 text-sm sm:text-base font-medium">
        <label for="<?php echo e($name); ?>"><?php echo e($title); ?></label>
        <div
            class="flex flex-row w-full border border-transparent focus-within:border-third focus-within:ring-1 focus-within:ring-third rounded-md">
            <label for="<?php echo e($name); ?>"
                class="py-2 px-3 border border-second bg-second text-white rounded-l-md">Rp. </label>
            <input type="number" id="<?php echo e($name); ?>" min="0" name="<?php echo e($name); ?>"
                placeholder="<?php echo e($placeholder); ?>" <?php echo e($xModel ? 'x-model=' . $xModel : ''); ?>

                x-bind:value="<?php echo e($xModel ? '' : $value); ?>"
                value="<?php echo e($value); ?>" class="flex-grow min-w-0 text-sm sm:text-base font-normal rounded-r-md border border-second focus:ring-0 focus:border-none bg-background">
        </div>
    </div>
</div>
<?php /**PATH C:\Peci\resources\views/components/admin/component/priceinput.blade.php ENDPATH**/ ?>