<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['route', 'active']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['route', 'active']); ?>
<?php foreach (array_filter((['route', 'active']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<a href="<?php echo e(route($route)); ?>" class="<?php echo e(request()->routeIs($active) ? 'text-second border-b-2 border-second' : 'border-b-2 border-transparent hover:text-black hover:border-black'); ?> text-wrap text-center duration-300">
    <?php echo e($slot); ?>

</a>
<?php /**PATH C:\Peci\resources\views/components/guest/navbutton.blade.php ENDPATH**/ ?>