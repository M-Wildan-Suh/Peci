<?php if (isset($component)) { $__componentOriginalf033baadcf10cc1e2c90a9d7fc105a54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf033baadcf10cc1e2c90a9d7fc105a54 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout.guest','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout.guest'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class=" space-y-8 sm:space-y-16 py-8 sm:py-16 px-4 md:px-8">
        <div class=" w-full max-w-[1080px] mx-auto">
            <div class=" space-y-8">
                <div class=" flex flex-row gap-2 items-center">
                    <div class=" w-1 h-6 bg-black rounded-full"></div>
                    <p class=" text-2xl font-black">Product</p>
                </div>
                <?php if (isset($component)) { $__componentOriginalfc5b0419c3a4ca06a4d24a96d80a3c45 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfc5b0419c3a4ca06a4d24a96d80a3c45 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.guest.component.product','data' => ['product' => $product]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest.component.product'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['product' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfc5b0419c3a4ca06a4d24a96d80a3c45)): ?>
<?php $attributes = $__attributesOriginalfc5b0419c3a4ca06a4d24a96d80a3c45; ?>
<?php unset($__attributesOriginalfc5b0419c3a4ca06a4d24a96d80a3c45); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfc5b0419c3a4ca06a4d24a96d80a3c45)): ?>
<?php $component = $__componentOriginalfc5b0419c3a4ca06a4d24a96d80a3c45; ?>
<?php unset($__componentOriginalfc5b0419c3a4ca06a4d24a96d80a3c45); ?>
<?php endif; ?>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf033baadcf10cc1e2c90a9d7fc105a54)): ?>
<?php $attributes = $__attributesOriginalf033baadcf10cc1e2c90a9d7fc105a54; ?>
<?php unset($__attributesOriginalf033baadcf10cc1e2c90a9d7fc105a54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf033baadcf10cc1e2c90a9d7fc105a54)): ?>
<?php $component = $__componentOriginalf033baadcf10cc1e2c90a9d7fc105a54; ?>
<?php unset($__componentOriginalf033baadcf10cc1e2c90a9d7fc105a54); ?>
<?php endif; ?><?php /**PATH C:\Peci\resources\views/guest/product.blade.php ENDPATH**/ ?>