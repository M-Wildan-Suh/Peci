<?php if (isset($component)) { $__componentOriginalf033baadcf10cc1e2c90a9d7fc105a54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf033baadcf10cc1e2c90a9d7fc105a54 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout.guest','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout.guest'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class=" space-y-8 sm:space-y-16 py-8 sm:py-16 px-4 md:px-8">
        <div class=" w-full max-w-[1080px] mx-auto">
            <div class=" w-full grid grid-cols-1 md:grid-cols-3 gap-4">
                <div class=" w-full pr-8">
                    <?php echo $__env->make('components.guest.profile-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div x-data="{  add: false }" class="md:col-span-2 w-full space-y-4" x-data="{ activeModal: 'semua' }">
                    <div class=" w-full p-4 bg-main rounded-md space-y-6">
                        <div class=" w-full">
                            <button @click="add = true"
                                class=" w-full py-2 bg-second hover:bg-third duration-300 font-black rounded-md text-white">Add
                                Address</button>
                            <?php echo $__env->make('admin.address.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <div class=" w-full space-y-2">
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class=" w-full rounded-md border <?php echo e($item->active ? 'bg-second/20' : ''); ?> border-second p-4">
                                    <p class=" font-black"><?php echo e($item->name); ?></p>
                                    <p class=" text-sm">+62 <?php echo e($item->phone_number); ?></p>
                                    <p class=" text-sm line-clamp-2"><?php echo e($item->address); ?>, (<?php echo e($item->additional); ?>)</p>
                                    <div class=" flex justify-between pt-2">
                                        <div class=" flex gap-2 w-full">
                                            <div x-data="{ edit: false }" class="">
                                                <button @click="edit = true"
                                                    class=" px-2 py-1 bg-second text-white hover:bg-third duration-300 rounded-md text-sm">Edit</button>
                                                <?php echo $__env->make('admin.address.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                            <?php if(!$item->active): ?>
                                                <form action="<?php echo e(route('address.destroy', ['address' => $item->id])); ?>"
                                                    method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button
                                                        class=" px-2 py-1 bg-second text-white hover:bg-third duration-300 rounded-md text-sm">Delete</button>
                                                </form>
                                            <?php endif; ?>
                                        </div>
                                        <?php if($item->active): ?>
                                            <button
                                                class=" px-2 py-1 bg-third text-white hover:bg-third duration-300 rounded-md text-sm">Active</button>
                                        <?php else: ?>
                                            <form action="<?php echo e(route('address.active', ['id' => $item->id])); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <button
                                                    class=" px-2 py-1 bg-second text-white hover:bg-third duration-300 rounded-md text-sm">Unactive</button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <script>
                                function submitForm(formId) {
                                    document.getElementById(formId).submit();
                                }
                            </script>        
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf033baadcf10cc1e2c90a9d7fc105a54)): ?>
<?php $attributes = $__attributesOriginalf033baadcf10cc1e2c90a9d7fc105a54; ?>
<?php unset($__attributesOriginalf033baadcf10cc1e2c90a9d7fc105a54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf033baadcf10cc1e2c90a9d7fc105a54)): ?>
<?php $component = $__componentOriginalf033baadcf10cc1e2c90a9d7fc105a54; ?>
<?php unset($__componentOriginalf033baadcf10cc1e2c90a9d7fc105a54); ?>
<?php endif; ?>
<?php /**PATH C:\Peci\resources\views/guest/address.blade.php ENDPATH**/ ?>