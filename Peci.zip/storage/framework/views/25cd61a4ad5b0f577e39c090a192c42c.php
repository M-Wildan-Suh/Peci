<?php if (isset($component)) { $__componentOriginalf033baadcf10cc1e2c90a9d7fc105a54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf033baadcf10cc1e2c90a9d7fc105a54 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout.guest','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout.guest'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class=" space-y-8 sm:space-y-16 py-8 sm:py-16 px-4 md:px-8">
        <div class=" w-full max-w-[1080px] mx-auto">
            <div class=" w-full grid grid-cols-1 md:grid-cols-3 gap-4">
                <div class=" w-full pr-8">
                    <?php echo $__env->make('components.guest.profile-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="md:col-span-2 w-full space-y-4" x-data="{ activeModal: 'semua' }">
                    <div class="p-4 sm:p-8 bg-main shadow sm:rounded-lg">
                        <div class="max-w-xl">
                            <?php echo $__env->make('profile.partials.update-profile-information-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
        
                    <div class="p-4 sm:p-8 bg-main shadow sm:rounded-lg">
                        <div class="max-w-xl">
                            <?php echo $__env->make('profile.partials.update-password-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
        
                    <div class="p-4 sm:p-8 bg-main shadow sm:rounded-lg">
                        <div class="max-w-xl">
                            <?php echo $__env->make('profile.partials.delete-user-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf033baadcf10cc1e2c90a9d7fc105a54)): ?>
<?php $attributes = $__attributesOriginalf033baadcf10cc1e2c90a9d7fc105a54; ?>
<?php unset($__attributesOriginalf033baadcf10cc1e2c90a9d7fc105a54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf033baadcf10cc1e2c90a9d7fc105a54)): ?>
<?php $component = $__componentOriginalf033baadcf10cc1e2c90a9d7fc105a54; ?>
<?php unset($__componentOriginalf033baadcf10cc1e2c90a9d7fc105a54); ?>
<?php endif; ?>

<?php /**PATH C:\Peci\resources\views/profile/edit.blade.php ENDPATH**/ ?>