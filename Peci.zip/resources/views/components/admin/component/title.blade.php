{{-- Title --}}
@props(['title'])
<div class=" px-4 rounded-lg">
    <div class=" w-full bg-white font-semibold p-3 rounded-md shadow-md shadow-black/20">{{$title}}</div>
</div>