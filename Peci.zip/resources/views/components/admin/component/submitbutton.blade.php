@props(['title'])
<div class=" w-full">
    <button class=" w-full py-3 text-sm sm:text-base rounded-md bg-second text-white font-semibold hover:bg-third duration-300">{{$title}}</button>
</div>