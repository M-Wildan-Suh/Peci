<x-app-layout title="Dashboard">
    <div class=" w-full p-6 bg-white rounded-md shadow-md shadow-black/20"></div>
</x-app-layout>